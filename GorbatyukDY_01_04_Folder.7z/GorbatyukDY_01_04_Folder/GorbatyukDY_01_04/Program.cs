﻿
using GorbatyukDY_01_04.Classes;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Serialization;

namespace GorbatyukDY_01_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Пример работы программы
            Console.WriteLine("Вывод примерных данных о созданой машине: ");
            Computer comp = new("MySimplePc", 4.1, 16);
            Console.WriteLine(comp.GetObjData());
            Console.WriteLine();
            Console.WriteLine("Q: " + comp.GetQ());
            Console.WriteLine();

            AdvancedComputer advComp = new("MyAdvancedPc", 4.5, 32, 1000);
            Console.WriteLine(advComp.GetObjData());
            Console.WriteLine();
            Console.WriteLine("Qp: " + advComp.GetQ());
            Console.WriteLine();

            //Создание объекта пользовтаелем
            int choice;
            do
            {
                Console.Write("Какой компьютер хотите заполнить? 0 - простой, 1 - расширенный: ");
                choice = int.Parse(Console.ReadLine());
            } while (choice != 0 && choice != 1);
            
            switch (choice)
            {
                case 0:
                    {
                        //Заполнение данных обекта класса Computer
                        //Проверка полей на не пустоту при вводе
                        string name = string.Empty;
                        do
                        {
                            Console.Write("Введите имя компьютера: ");
                            name = Console.ReadLine();
                            Console.WriteLine();
                        } while (string.IsNullOrEmpty(name));
                        double freq = 0;
                        do
                        {
                            Console.Write("Введите тактовую частоту ЦП (пример: 4,1): ");
                            freq = double.Parse(Console.ReadLine());
                            Console.WriteLine();
                        } while (freq <= 0.0);
                        uint ram = 0;
                        do
                        {
                            Console.Write("Введите объем озу (обязательно > 0): ");
                            ram = uint.Parse(Console.ReadLine());
                            Console.WriteLine();
                        } while (ram <= 0);
                        //Конец проверок
                        Computer computer = new(name, freq, ram); 
                        //Вывод данных созданного объекта
                        Console.WriteLine("Вывод данных о созданой машине: ");
                        Console.WriteLine(computer.GetObjData());
                        Console.WriteLine();
                        Console.WriteLine("Q: " + computer.GetQ());
                        Console.WriteLine();
                        break;
                    }
                case 1:
                    {
                        //Заполнение данных обекта класса AdvancedComputer
                        //Проверка полей на не пустоту при вводе
                        string name = string.Empty;
                        do
                        {
                            Console.Write("Введите имя компьютера: ");
                            name = Console.ReadLine();
                            Console.WriteLine();
                        } while (string.IsNullOrEmpty(name));
                        double freq = 0;
                        do
                        {
                            Console.Write("Введите тактовую частоту ЦП (пример: 4,1): ");
                            freq = double.Parse(Console.ReadLine());
                            Console.WriteLine();
                        } while (freq <= 0.0);
                        uint ram = 0;
                        do
                        {
                            Console.Write("Введите объем озу (обязательно > 0): ");
                            ram = uint.Parse(Console.ReadLine());
                            Console.WriteLine();
                        } while (ram <= 0);
                        uint driveVolume = 0;
                        do
                        {
                            Console.Write("Введите объем накопителя (обязательно > 0): ");
                            driveVolume = uint.Parse(Console.ReadLine());
                            Console.WriteLine();
                        } while (driveVolume <= 0);
                        //Конец проверок
                        AdvancedComputer computer = new(name, freq, ram, driveVolume);
                        //Вывод данных созданного объекта
                        Console.WriteLine("Вывод данных о созданой машине: ");
                        Console.WriteLine(computer.GetObjData());
                        Console.WriteLine();
                        Console.WriteLine("Qp: " + computer.GetQ());
                        Console.WriteLine();
                        break;
                    }
            }
        }
    }
}
