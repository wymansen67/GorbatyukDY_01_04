﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace GorbatyukDY_01_04.Classes
{
    public class Computer
    {
        private string Name { get; set; } = string.Empty;

        private double Frequency { get; set; }

        private uint RAM { get; set; }

        public Computer(string name, double frequency, uint ram)
        {
            Name = name;
            Frequency = frequency;
            RAM = ram;
        }
        //Получение данных об объекте
        public virtual string GetObjData()
        {
            return $"Наименование: {Name}\nТактовая частота ЦП: {Frequency} Ггц\nОбъем ОЗУ: {RAM} гб";
        }
        //Метод получения Q
        public virtual double GetQ()
        {
            return (0.3 * Frequency) + RAM;
        } 
    }
}
