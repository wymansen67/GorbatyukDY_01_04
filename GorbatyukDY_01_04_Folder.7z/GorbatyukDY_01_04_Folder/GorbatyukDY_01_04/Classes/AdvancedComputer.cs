﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GorbatyukDY_01_04.Classes
{
    public class AdvancedComputer : Computer
    {
        private uint DriveVolume { get; set; }

        public AdvancedComputer(string name, double frequency, uint ram, uint driveVolume) : base(name, frequency, ram)
        {
            DriveVolume = driveVolume;
        }

        //Получение данных об объекте
        public override string GetObjData()
        {
            return base.GetObjData() + $"\nОбъем винчестера: {DriveVolume} гб";
        }
        //Метод получения Qp
        public override double GetQ()
        {
            if (DriveVolume > 500)
            {
                return base.GetQ() + 0.5 * DriveVolume;
            }
            else if (DriveVolume > 0)
            {
                return base.GetQ() + 1.5 * DriveVolume;
            }
            else return -1.0;
        }
    }
}
